#!/bin/bash

java -cp .:lib/* org.opens.webdevdataquery.QueryExecutor "$@"
