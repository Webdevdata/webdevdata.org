#!/bin/bash

if [ -z "$1" ] || [ ! -d "$1" ]; then
	echo "$0 gives usage statitics of HTML attributes (HTML 4 and HTML 5)"
	echo "Usage $0 <path-to-webDevData-directory>";
	exit 0;
	fi
	

ATTRIBUTES="[abbr] [accept] [accept-charset] [accesskey] [action] [align] [alink] [allowfullscreen] [alt] [archive] [async] [autocomplete] [autofocus] [autoplay] [axis] [background] [bgcolor] [border] [cellpadding] [cellspacing] [challenge] [char] [charoff] [charset] [checked] [cite] [class] [classid] [clear] [code] [codebase] [codetype] [color] [cols] [colspan] [command] [compact] [content] [contenteditable] [contextmenu] [controls] [coords] [crossorigin] [data] [datetime] [declare] [default] [defer] [dir] [dirname] [disabled] [download] [draggable] [dropzone] [enctype] [face] [for] [form] [formaction] [formenctype] [formmethod] [formnovalidate] [formtarget] [frame] [frameborder] [headers] [height] [hidden] [high] [href] [hreflang] [hspace] [http-equiv] [icon] [id] [inert] [inputmode] [ismap] [itemid] [itemprop] [itemref] [itemscope] [itemtype] [keytype] [kind] [label] [lang] [language] [link] [list] [longdesc] [loop] [low] [manifest] [marginheight] [marginwidth] [max] [maxlength] [media] [mediagroup] [menu] [method] [min] [multiple] [muted] [name] [nohref] [noresize] [noshade] [novalidate] [nowrap] [object] [onblur] [onchange] [onclick] [ondblclick] [onfocus] [onkeydown] [onkeypress] [onkeyup] [onload] [onmousedown] [onmousemove] [onmouseout] [onmouseover] [onmouseup] [onreset] [onselect] [onsubmit] [onunload] [open] [optimum] [pattern] [placeholder] [poster] [preload] [profile] [prompt] [radiogroup] [readonly] [rel] [required] [rev] [reversed] [rows] [rowspan] [rules] [sandbox] [scheme] [scope] [scoped] [scrolling] [seamless] [selected] [shape] [size] [sizes] [span] [spellcheck] [src] [srcdoc] [srclang] [standby] [start] [step] [style] [summary] [tabindex] [target] [text] [title] [translate] [type] [typemustmatch] [usemap] [valign] [value] [valuetype] [version] [vlink] [vspace] [width] [wrap]"


./webdevdata-query.sh "$1" ${ATTRIBUTES}
